1. AppleParentage1.0 was wrote by python 3.7.
2. The sample configuration files were given in directory of 'example'.
3. All configuration files should be placed in the working directory.